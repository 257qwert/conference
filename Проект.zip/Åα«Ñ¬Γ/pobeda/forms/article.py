from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField
from wtforms import SubmitField, SelectField
from wtforms.validators import DataRequired


class ArticleForm(FlaskForm):
    title = StringField('Заголовок', validators=[DataRequired()])
    category = SelectField('Секция статьи', choices=[('Физика', 'Физика'), ('Математика', 'Математика'),
                                                     ('Информатика', 'Информатика'), ('Химия', 'Химия')])
    content = TextAreaField("Содержание")
    annotation = StringField("Аннотация", validators=[DataRequired()])
    submit = SubmitField('Отправить на проверку')
