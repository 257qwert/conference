from flask import Flask, render_template, redirect, request, abort
from data import db_session
from data.users import User
from data.articles import Articles
from forms.user import RegisterForm
from forms.login import LoginForm
from forms.article import ArticleForm
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
import logging

logging.basicConfig(filename='log/main.log')
app = Flask(__name__)
app.config['SECRET_KEY'] = 'pobeda_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/')
def hello_world():
    return render_template('index.html')


@app.route('/physics')
def physics():
    db_sess = db_session.create_session()
    articles = db_sess.query(Articles).filter(Articles.category == 'Физика', Articles.status == 'Принято')
    return render_template('conference_page.html', title='Физика', category='physics', articles=articles)


@app.route('/mathematics')
def mathematics():
    db_sess = db_session.create_session()
    articles = db_sess.query(Articles).filter(Articles.category == 'Математика', Articles.status == 'Принято')
    return render_template('conference_page.html', title='Математика', category='mathematics', articles=articles)


@app.route('/informatics')
def informatics():
    db_sess = db_session.create_session()
    articles = db_sess.query(Articles).filter(Articles.category == 'Информатика', Articles.status == 'Принято')
    return render_template('conference_page.html', title='Информатика', category='informatics', articles=articles)


@app.route('/chemistry')
def chemistry():
    db_sess = db_session.create_session()
    articles = db_sess.query(Articles).filter(Articles.category == 'Химия', Articles.status == 'Принято')
    return render_template('conference_page.html', title='Химия', category='chemistry', articles=articles)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/profile')
@login_required
def profile():
    db_sess = db_session.create_session()
    articles = db_sess.query(Articles).filter(Articles.user == current_user)
    return render_template('profile.html', articles=articles)


@app.route('/articles',  methods=['GET', 'POST'])
@login_required
def add_articles():
    form = ArticleForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        articles = Articles()
        articles.title = form.title.data
        articles.content = form.content.data
        articles.category = form.category.data
        articles.annotation = form.annotation.data

        current_user.articles.append(articles)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect('/')
    return render_template('articles.html', form=form)


@app.route('/articles/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_article(id):
    form = ArticleForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        articles = db_sess.query(Articles).filter(Articles.id == id, Articles.user == current_user).first()
        if articles:
            form.title.data = articles.title
            form.content.data = articles.content
            form.category.data = articles.category
            form.annotation.data = articles.annotation
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        articles = db_sess.query(Articles).filter(Articles.id == id,Articles.user == current_user).first()
        if articles:
            articles.title = form.title.data
            articles.content = form.content.data
            articles.category = form.category.data
            articles.annotation = form.annotation.data
            articles.status = 'На рассмотрении'
            db_sess.commit()
            return redirect('/')
        else:
            abort(404)
    return render_template('articles.html', form=form)


@app.route('/articles_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def articles_delete(id):
    db_sess = db_session.create_session()
    if current_user.role == 'user':
        articles = db_sess.query(Articles).filter(Articles.id == id, Articles.user == current_user).first()
    elif current_user.role == 'admin':
        articles = db_sess.query(Articles).filter(Articles.id == id).first()
    else:
        abort(404)
    if articles:
        db_sess.delete(articles)
        db_sess.commit()
    else:
        abort(404)
    if current_user.role == 'user':
        return redirect('/')
    else:
        return redirect('/moderate')


@app.route('/ok/<int:id>', methods=['GET', 'POST'])
@login_required
def ok(id):
    if current_user.role == 'admin':
        db_sess = db_session.create_session()
        articles = db_sess.query(Articles).filter(Articles.id == id).first()
        if articles:
            articles.status = 'Принято'
            db_sess.commit()
        else:
            abort(404)
        return redirect('/moderate')
    else:
        return redirect('/')


@app.route('/moderate', methods=['GET', 'POST'])
@login_required
def moderate():
    if current_user.role == 'admin':
        db_sess = db_session.create_session()
        articles = db_sess.query(Articles).filter(Articles.status == 'На рассмотрении')
        return render_template('moderate.html', articles=articles)
    else:
        return redirect('/')


def main():
    db_session.global_init('db/main_db.sqlite')
    app.run()


if __name__ == '__main__':
    main()
